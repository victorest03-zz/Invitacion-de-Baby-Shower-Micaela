TrueTypeFont: Hawaiian Punk
Dennis Ludlow Productions 2002 all rights reserved
Sharkshock Productions

This is the first font i've designed in about a year. Please don't email me for requests because
i just don't have the time. Let's just say i picked up a project i started longgg ago out of shear boredom. As you'll notice, the punctuation is extremely minimal as well as  the symbols. This was no accident. If you purchase a license for this or any of my fonts, i'll add the missing ones. Hope you enjoy!.

check out my graphic archive at www.sharkshock.com
                                  "because boring design SUCKS!"